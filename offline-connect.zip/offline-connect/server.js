// OfflineConnect: zero-dependency LAN server (no internet needed).
// Serves the app, relays WebRTC signaling (SSE + POST) and holds the Instagram-style feed in memory.
const https = require('https');
const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { execSync } = require('child_process');

const PORT = process.env.PORT || 8443;
const PUB = path.join(__dirname, 'public');
const CERT_DIR = path.join(__dirname, 'certs');
const DATA = path.join(__dirname, 'feed.json');

// ---- state ----
const clients = new Map(); // name -> res
let feed = [];
try { feed = JSON.parse(fs.readFileSync(DATA, 'utf8')); } catch (e) {}
const saveFeed = () => fs.writeFile(DATA, JSON.stringify(feed), () => {});

const send = (res, event, data) => res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
const broadcast = (event, data) => clients.forEach(r => send(r, event, data));
const peers = () => [...clients.keys()];
const publicFeed = () => feed.slice().reverse();

function body(req) {
  return new Promise(resolve => {
    let b = '';
    req.on('data', c => { b += c; if (b.length > 8e6) req.destroy(); });
    req.on('end', () => { try { resolve(JSON.parse(b || '{}')); } catch (e) { resolve({}); } });
  });
}
const json = (res, obj, code = 200) => { res.writeHead(code, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(obj)); };

const types = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.svg': 'image/svg+xml' };

async function handler(req, res) {
  const url = new URL(req.url, 'http://x');

  if (url.pathname === '/events') {
    const name = (url.searchParams.get('name') || '').trim().slice(0, 20);
    if (!name || clients.has(name)) { res.writeHead(409); return res.end('name taken'); }
    res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive' });
    clients.set(name, res);
    send(res, 'feed', publicFeed());
    broadcast('peers', peers());
    const ka = setInterval(() => res.write(': ka\n\n'), 15000);
    req.on('close', () => { clearInterval(ka); if (clients.get(name) === res) clients.delete(name); broadcast('peers', peers()); });
    return;
  }

  if (req.method === 'POST' && url.pathname === '/signal') {
    const { to, from, data } = await body(req);
    const target = clients.get(to);
    if (target) send(target, 'signal', { from, data });
    return json(res, { ok: !!target });
  }

  if (req.method === 'POST' && url.pathname === '/post') {
    const { user, image, caption } = await body(req);
    if (!user || !image) return json(res, { error: 'bad' }, 400);
    feed.push({ id: Date.now() + '-' + Math.random().toString(36).slice(2, 6), user, image, caption: (caption || '').slice(0, 300), likes: [], comments: [], ts: Date.now() });
    if (feed.length > 100) feed.shift();
    saveFeed(); broadcast('feed', publicFeed());
    return json(res, { ok: true });
  }

  if (req.method === 'POST' && url.pathname === '/like') {
    const { id, user } = await body(req);
    const p = feed.find(x => x.id === id);
    if (p && user) {
      const i = p.likes.indexOf(user);
      i === -1 ? p.likes.push(user) : p.likes.splice(i, 1);
      saveFeed(); broadcast('feed', publicFeed());
    }
    return json(res, { ok: true });
  }

  if (req.method === 'POST' && url.pathname === '/comment') {
    const { id, user, text } = await body(req);
    const p = feed.find(x => x.id === id);
    if (p && user && text) { p.comments.push({ user, text: text.slice(0, 200) }); saveFeed(); broadcast('feed', publicFeed()); }
    return json(res, { ok: true });
  }

  // static
  let f = url.pathname === '/' ? '/index.html' : url.pathname;
  const full = path.join(PUB, path.normalize(f));
  if (!full.startsWith(PUB) || !fs.existsSync(full)) { res.writeHead(404); return res.end('not found'); }
  res.writeHead(200, { 'Content-Type': types[path.extname(full)] || 'application/octet-stream' });
  fs.createReadStream(full).pipe(res);
}

// ---- TLS (camera/mic need a secure context, even on a LAN) ----
function tls() {
  const key = path.join(CERT_DIR, 'key.pem'), cert = path.join(CERT_DIR, 'cert.pem');
  if (!fs.existsSync(key)) {
    fs.mkdirSync(CERT_DIR, { recursive: true });
    try {
      execSync(`openssl req -x509 -newkey rsa:2048 -nodes -keyout "${key}" -out "${cert}" -days 825 -subj "/CN=offline-connect"`, { stdio: 'ignore' });
    } catch (e) { return null; }
  }
  return { key: fs.readFileSync(key), cert: fs.readFileSync(cert) };
}

const opts = tls();
const server = opts ? https.createServer(opts, handler) : http.createServer(handler);
server.listen(PORT, '0.0.0.0', () => {
  const proto = opts ? 'https' : 'http';
  console.log('\nOfflineConnect running. Join the SAME Wi-Fi / phone hotspot and open:');
  Object.values(os.networkInterfaces()).flat().filter(i => i.family === 'IPv4' && !i.internal)
    .forEach(i => console.log(`  ${proto}://${i.address}:${PORT}`));
  if (!opts) console.log('\n! openssl not found: video/camera will only work on localhost. Install openssl and delete ./certs.');
  else console.log('\nFirst visit shows a certificate warning: tap Advanced -> Proceed (it is your own server).');
});
